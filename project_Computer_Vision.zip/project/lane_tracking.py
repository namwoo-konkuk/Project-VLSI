import numpy as np
import cv2
import pickle
import glob

from matplotlib import image as mpimg
from matplotlib import pyplot as plt
from pylab import *

##################################################################
# width: 640, height: 480


global left_lane
global right_lane

class Lane():
    def __init__(self):
        # was the line detected in the last iteration?
        self.detected = False  
        # x values of the last n fits of the line
        self.recent_xfitted = [] 
        #average x values of the fitted line over the last n iterations
        self.bestx = np.zeros(480)
        #polynomial coefficients averaged over the last n iterations
        self.best_fit = np.zeros(3)  
        #polynomial coefficients for the most recent fit
        self.current_fit = [np.array([False])]  
        #radius of curvature of the line in some units
        self.radius_of_curvature = np.zeros(1)
        #distance in meters of vehicle center from the line
        self.line_base_pos = np.zeros(1)
        #difference in fit coefficients between last and new fits
        self.diffs = np.array([0,0,0], dtype='float') 
        #x values for detected line pixels
        self.allx = None  
        #y values for detected line pixels
        self.ally = None
        #smoothen the n frames 
        self.smoothen_nframes = 10
        #first frame 
        self.first_frame = True
left_lane = Lane()
right_lane = Lane()

##########################################################################
################################calibration###############################
##########################################################################
def do_calibration():
    # for camera calibration and store the result in a file "camera_cal/camera_cal.p"
    # array to store the obj point and image points
    objpoints = []
    imgpoints = []
    objp = np.zeros((6*9,3),np.float32)
    objp[:,:2] = np.mgrid[0:9,0:6].T.reshape(-1,2)
    images = glob.glob("camera_cal/cal*")
    for fnames in images:
        img = mpimg.imread(fnames)
        gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
        ret, corners = cv2.findChessboardCorners(gray,(9,6),None)
        if ret == True:
            imgpoints.append(corners)
            objpoints.append(objp)
            img = cv2.drawChessboardCorners(img,(9,6),corners,ret)
    img_size = mpimg.imread("camera_cal/calibration1.jpg")
    ret,mtx,dist,rvecs,tvecs = cv2.calibrateCamera(objpoints,imgpoints,gray.shape[::-1],None,None)
    # save the calibration data in a pickle file to use later
    camera_cal_val = "camera_cal/camera_cal.p"
    output = open(camera_cal_val,'wb')

    mydict2 = {'mtx':1,'dist':2}
    mydict2['mtx'] = mtx
    mydict2['dist'] = dist
    pickle.dump(mydict2,output)
    output.close()

def get_camera_calibration():
    dist_pickle = pickle.load(open("camera_cal/camera_cal.p","rb"),encoding="utf8")
    mtx = dist_pickle["mtx"]
    dist = dist_pickle["dist"]
    return mtx, dist


##########################################################################
################################thresholding##############################
##########################################################################
def region_of_interest(img, vertices):
    #defining a blank mask to start with
    mask = np.zeros_like(img, dtype=np.uint8)
    #defining a 3 channel or 1 channel color to fill the mask with depending on the input image
    if len(img.shape) > 2:
        channel_count = img.shape[2]  # i.e. 3 or 4 depending on your image
        ignore_mask_color = (255,) * channel_count
    else:
        ignore_mask_color = 255

    #filling pixels inside the polygon defined by "vertices" with the fill color    
    cv2.fillPoly(mask, vertices, ignore_mask_color)
    #returning the image only where mask pixels are nonzero
    masked_image = cv2.bitwise_and(img, mask)
    return masked_image

def color_thresh(b_img,v_img,b_thresh = (0,255), v_thresh = (0,255)):
    b_binary = np.zeros_like(b_img).astype(np.uint8)
    b_binary[(b_img > b_thresh[0]) & (b_img <= b_thresh[1])] = 1
    v_binary = np.zeros_like(b_img).astype(np.uint8)
    v_binary[(v_img > v_thresh[0]) & (v_img <= v_thresh[1])] = 1
    c_binary = ((b_binary == 1) & (v_binary == 1))
    
    return c_binary

def gray_thresh(gray, g_thresh = 255):
    img = cv2.equalizeHist(gray)
    ret,g_binary = cv2.threshold(img,thresh=g_thresh,maxval=255,type=cv2.THRESH_BINARY)

    return g_binary

def thresholding1(img,b_thresh=(0,255),v_thresh=(0,255),g_thresh=(255)):
    imshape = img.shape
    
    #region of interest is applied here 
    vertices = np.array([[(.55*imshape[1], 0.6*imshape[0]), (imshape[1],imshape[0]),(0,imshape[0]),(.45*imshape[1], 0.6*imshape[0])]], dtype=np.int32)
    img = region_of_interest(img.astype(np.uint8), vertices)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.uint8)

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    v_channel = hsv[:,:,2].astype(np.uint8)

    lab = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    b_channel = lab[:,:,2].astype(np.uint8)


    c_binary = color_thresh(b_channel, v_channel, b_thresh=b_thresh, v_thresh = v_thresh).astype(np.uint8)
    cv2.imshow("c_binary",c_binary*255)

    g_binary = gray_thresh(gray, g_thresh)//255
    cv2.imshow("g_binary",g_binary*255)

    combined_binary = np.zeros_like(c_binary)
    combined_binary[(c_binary == 1) | (g_binary == 1)] = 1
    #combined_binary = np.dstack(( combined_binary,combined_binary,combined_binary)).astype(np.float32)

    cv2.imshow("combined_binary",combined_binary*255)
    return combined_binary

def binary_threshold(img, low, high):    
    if len(img.shape) == 2:
        output = np.zeros_like(img)
        mask = (img >= low) & (img <= high)
        
    elif len(img.shape) == 3:
        output = np.zeros_like(img[:,:,0])
        mask = (img[:,:,0] >= low[0]) & (img[:,:,0] <= high[0]) \
            & (img[:,:,1] >= low[1]) & (img[:,:,1] <= high[1]) \
            & (img[:,:,2] >= low[2]) & (img[:,:,2] <= high[2])
            
    output[mask] = 1
    return output

def thresholding2(img):
    hls = cv2.cvtColor(img, cv2.COLOR_RGB2HLS)
    L = hls[:,:,1]
    L_max, L_mean = np.max(L), np.mean(L)
    S = hls[:,:,2]
    S_max, S_mean = np.max(S), np.mean(S)

    # YELLOW
    L_adapt_yellow = max(80, int(L_mean * 1.25))
    S_adapt_yellow = max(int(S_max * 0.25), int(S_mean * 1.75))
    hls_low_yellow = np.array((15, L_adapt_yellow, S_adapt_yellow))
    hls_high_yellow = np.array((0, 255, 255))

    hls_yellow = binary_threshold(hls, hls_low_yellow, hls_high_yellow)
    cv2.imshow("yellow",hls_yellow*255)

    # WHITE
    L_adapt_white =  max(160, int(L_max *0.8),int(L_mean * 1.25))
    hls_low_white = np.array((0, L_adapt_white,  0))
    hls_high_white = np.array((255, 255, 255))

    hls_white = binary_threshold(hls, hls_low_white, hls_high_white)
    cv2.imshow("white",hls_white*255)

    hls_binary = hls_yellow | hls_white
    cv2.imshow("hls_binary",hls_binary*255)

    return hls_binary


##########################################################################
################################perspective###############################
##########################################################################
def perspective_transform(img,src=None,dst=None):
    imshape = img.shape

    vertices = np.array([[(.55*imshape[1], .63*imshape[0]), (.45*imshape[1],.63*imshape[0]), (0,imshape[0]), (imshape[1],imshape[0])]],dtype=np.float32)
    
    src= np.float32(vertices)
    dst = np.float32([[0.75*img.shape[1],0],[0.25*img.shape[1],0],[0.25*img.shape[1],img.shape[0]],[0.75*img.shape[1],img.shape[0]]])

    M = cv2.getPerspectiveTransform(src, dst)
    minv = cv2.getPerspectiveTransform(dst, src)
    
    img_size = (imshape[1], imshape[0])
    warped = cv2.warpPerspective(img, M, img_size, flags = cv2.INTER_LINEAR)

    cv2.imshow("warped",warped*255)
    
    return warped, minv



##########################################################################
##############################find_lanes##############################
##########################################################################
def find_lanes(binary_warped):
    histogram = np.sum(binary_warped[binary_warped.shape[0]//2:,:], axis=0)

    out_img = np.dstack((binary_warped, binary_warped, binary_warped))*255

    midpoint = np.int(histogram.shape[0]//2)
    leftx_base = np.argmax(histogram[:midpoint])
    rightx_base = np.argmax(histogram[midpoint:]) + midpoint

    nwindows = 9

    window_height = np.int(binary_warped.shape[0]//nwindows)

    nonzero = binary_warped.nonzero()
    nonzeroy = np.array(nonzero[0])
    nonzerox = np.array(nonzero[1])

    leftx_current = leftx_base
    rightx_current = rightx_base

    margin = 100

    minpix = 50

    left_lane_inds = []
    right_lane_inds = []


    for window in range(nwindows):
        win_y_low = binary_warped.shape[0] - (window+1)*window_height
        win_y_high = binary_warped.shape[0] - window*window_height
        win_xleft_low = leftx_current - margin
        win_xleft_high = leftx_current + margin
        win_xright_low = rightx_current - margin
        win_xright_high = rightx_current + margin
        
        good_left_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) & (nonzerox >= win_xleft_low) & (nonzerox < win_xleft_high)).nonzero()[0]
        good_right_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) & (nonzerox >= win_xright_low) & (nonzerox < win_xright_high)).nonzero()[0]

        left_lane_inds.append(good_left_inds)
        right_lane_inds.append(good_right_inds)

        if len(good_left_inds) > minpix:
            leftx_current = np.int(np.mean(nonzerox[good_left_inds]))
        if len(good_right_inds) > minpix:        
            rightx_current = np.int(np.mean(nonzerox[good_right_inds]))

    left_lane_inds = np.concatenate(left_lane_inds)
    right_lane_inds = np.concatenate(right_lane_inds)

    leftx = nonzerox[left_lane_inds]
    lefty = nonzeroy[left_lane_inds] 
    rightx = nonzerox[right_lane_inds]
    righty = nonzeroy[right_lane_inds] 

    if (leftx.size < 5):
        left_lane.detected = False
    else:
        left_lane.detected = True
    
    if (rightx.size < 5):
        right_lane.detected = False
    else:
        right_lane.detected = True
        
    if left_lane.detected == True & right_lane.detected == True:
        left_fit = np.polyfit(lefty, leftx, 2)
        right_fit = np.polyfit(righty, rightx, 2)
        left_lane.best_fit = np.vstack([left_lane.best_fit,left_fit])
        left_lane.best_fit[0] = left_fit
        right_lane.best_fit = np.vstack([right_lane.best_fit,right_fit])
        right_lane.best_fit[0] = right_fit
        left_lane.best_fit = np.average(left_lane.best_fit[-left_lane.smoothen_nframes:], axis = 0)
        right_lane.best_fit = np.average(right_lane.best_fit[-right_lane.smoothen_nframes:], axis = 0)
    else: 
        left_fit = left_lane.best_fit
        right_fit = right_lane.best_fit

    ploty = np.linspace(0, out_img.shape[0]-1, out_img.shape[0] )
    left_fitx = left_fit[0]*ploty**2 + left_fit[1]*ploty + left_fit[2]
    right_fitx = right_fit[0]*ploty**2 + right_fit[1]*ploty + right_fit[2]

    if left_lane.first_frame == True:
        left_lane.first_frame = False
        left_lane.bestx = np.vstack([left_lane.bestx,left_fitx])
        left_lane.bestx[0] = left_fitx
    
    if ((left_fitx[0] > right_fitx[0]) | (abs(left_fitx[0] - right_fitx[0])<200) | (abs(left_fitx[0] - right_fitx[0])>350) | (left_fitx[0] > 400 )):
        left_lane.bestx = np.vstack([left_lane.bestx,left_lane.bestx])  
    else:
        left_lane.bestx = np.vstack([left_lane.bestx,left_fitx])
        
    left_lane.bestx = np.average(left_lane.bestx[-left_lane.smoothen_nframes:], axis = 0)
    
    if right_lane.first_frame == True:
        right_lane.first_frame = False
        right_lane.bestx = np.vstack([right_lane.bestx,right_fitx])
        right_lane.bestx[0] = right_fitx
    
    if ((left_fitx[0] > right_fitx[0]) | (abs(left_fitx[0] - right_fitx[0])<200) | (abs(left_fitx[0] - right_fitx[0])>350) | (right_fitx[0] > 600)):
        right_lane.bestx = np.vstack([right_lane.bestx,right_lane.bestx])
    else:
        right_lane.bestx = np.vstack([right_lane.bestx,right_fitx])
    
    right_lane.bestx = np.average(right_lane.bestx[-right_lane.smoothen_nframes:], axis = 0)
    
    window_img = np.zeros_like(out_img)
    margin = 10
    
    out_img[nonzeroy[left_lane_inds], nonzerox[left_lane_inds]] = [255, 0, 255]
    out_img[nonzeroy[right_lane_inds], nonzerox[right_lane_inds]] = [255, 0, 255]

    left_line_window1 = np.array([np.transpose(np.vstack([left_lane.bestx-margin, ploty]))])
    left_line_window2 = np.array([np.flipud(np.transpose(np.vstack([left_lane.bestx+margin, ploty])))])
    left_line_pts = np.hstack((left_line_window1, left_line_window2))
    right_line_window1 = np.array([np.transpose(np.vstack([right_lane.bestx-margin, ploty]))])
    right_line_window2 = np.array([np.flipud(np.transpose(np.vstack([right_lane.bestx+margin, ploty])))])
    right_line_pts = np.hstack((right_line_window1, right_line_window2))

    cv2.fillPoly(window_img, np.int_([left_line_pts]), (0,255, 0))
    cv2.fillPoly(window_img, np.int_([right_line_pts]), (0,255, 0))
    result = cv2.addWeighted(out_img, 1, window_img, 1, 0)
    
    left_line_window1 = np.array([np.transpose(np.vstack([left_fitx-margin, ploty]))])
    left_line_window2 = np.array([np.flipud(np.transpose(np.vstack([left_fitx+margin, ploty])))])
    left_line_pts = np.hstack((left_line_window1, left_line_window2))
    right_line_window1 = np.array([np.transpose(np.vstack([right_fitx-margin, ploty]))])
    right_line_window2 = np.array([np.flipud(np.transpose(np.vstack([right_fitx+margin, ploty])))])
    right_line_pts = np.hstack((right_line_window1, right_line_window2))

    cv2.fillPoly(window_img, np.int_([left_line_pts]), (0,0, 255))
    cv2.fillPoly(window_img, np.int_([right_line_pts]), (0,0, 255))
    result = cv2.addWeighted(out_img, 1, window_img, 1, 0)
    
    if (leftx.size > 2 | rightx.size > 2) :
        y_eval = np.max(ploty)
        ym_per_pix = 30/360 # meters per pixel in y dimension
        xm_per_pix = 3.7/400 # meters per pixel in x dimension

        left_fit_cr = np.polyfit(lefty*ym_per_pix, leftx*xm_per_pix, 2)
        right_fit_cr = np.polyfit(righty*ym_per_pix, rightx*xm_per_pix, 2)

        left_curverad = ((1 + (2*left_fit_cr[0]*y_eval*ym_per_pix + left_fit_cr[1])**2)**1.5) / np.absolute(2*left_fit_cr[0])
        right_curverad = ((1 + (2*right_fit_cr[0]*y_eval*ym_per_pix + right_fit_cr[1])**2)**1.5) / np.absolute(2*right_fit_cr[0])

        lane_centre = (left_fitx[-1] + right_fitx[-1])/2.0
        camera_centre = result.shape[1]/2.0

        dist_centre_val = (lane_centre - camera_centre)*xm_per_pix
        avg_cur = (right_curverad+left_curverad)/2.0
        
        left_lane.line_base_pos = np.vstack([left_lane.line_base_pos,dist_centre_val])
        left_lane.line_base_pos[0] = dist_centre_val
        left_lane.line_base_pos = np.average(left_lane.line_base_pos[-left_lane.smoothen_nframes:], axis = 0)
        
        left_lane.radius_of_curvature = np.vstack([left_lane.radius_of_curvature,avg_cur])
        left_lane.radius_of_curvature[0] = avg_cur
        left_lane.radius_of_curvature = np.average(left_lane.radius_of_curvature[-left_lane.smoothen_nframes:], axis = 0)

    else:
        dist_centre_val = left_lane.line_base_pos
        avg_cur = left_lane.radius_of_curvature
    
    left_lane.detected == False
    right_lane.detected == False
    return left_lane.bestx, right_lane.bestx, ploty, left_lane.radius_of_curvature, left_lane.line_base_pos

def draw_lanes(undist, left_fitx, right_fitx, ploty,Minv,avg_cur,dist_centre):
    color_warp = np.zeros_like(undist).astype(np.uint8)

    pts_left = np.array([np.transpose(np.vstack([left_fitx, ploty]))])
    pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx, ploty])))])
    pts = np.hstack((pts_left, pts_right))

    cv2.fillPoly(color_warp, np.int_([pts]), (255, 0, 0))
    
    pts_left = np.array([np.transpose(np.vstack([left_fitx[400:], ploty[400:]]))])
    pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx[400:], ploty[400:]])))])
    pts = np.hstack((pts_left, pts_right))

    cv2.fillPoly(color_warp, np.int_([pts]), (0, 255, 0))
    
    newwarp = cv2.warpPerspective(color_warp, Minv, (undist.shape[1], undist.shape[0])) 

    result = cv2.addWeighted(undist, 1, newwarp, 0.4, 0)

    curvature = "Estimated lane curvature %.2fm" % (avg_cur)
    dist_centre = "Estimated offset from lane center %.2fm" % (dist_centre)
    font = cv2.FONT_HERSHEY_SIMPLEX

    cv2.putText(result, curvature, (50, 50), font, 0.5, (255,255,255), 1)
    cv2.putText(result, dist_centre, (50, 100), font, 0.5, (255,255,255), 1)

    return result
