from __future__ import division

from lane_tracking import *
from yolo import *
from optical_flow import *
from util import *
from torch.autograd import Variable
from darknet import Darknet

import time
import torch 
import torch.nn as nn
import numpy as np
import cv2
import pickle


global mtx
global dist

def lane_tracking(img):
    # do_calibration()
    mtx,dist = get_camera_calibration()

    # undistort the image
    undist = cv2.undistort(img,mtx,dist,None,mtx)

    # thresholding
    combined_binary = thresholding1(undist,b_thresh=(169,249),v_thresh=(230,255),g_thresh=(250))
    #combined_binary = thresholding2(undist)
    #combined_binary = thresholding3(undist)

    # perspective transformation

    warped, unwarp_matrix = perspective_transform(combined_binary)

    left_fitx, right_fitx, ploty, avg_cur, dist_centre = find_lanes(warped)
    
    result = draw_lanes(undist, left_fitx, right_fitx, ploty, unwarp_matrix, avg_cur, dist_centre)

    return result


if __name__ == '__main__':
    #########################################for YOLO#########################################
    cfgfile = "cfg/yolov3.cfg"
    weightsfile = "yolov3.weights"
    num_classes = 80


    args = arg_parse()
    confidence = float(args.confidence)
    nms_thesh = float(args.nms_thresh)
    start = 0
    CUDA = torch.cuda.is_available()

    # bbox_attrs = 5 + num_classes

    model = Darknet(cfgfile)
    model.load_weights(weightsfile)

    model.net_info["height"] = args.reso
    inp_dim = int(model.net_info["height"])

    assert inp_dim % 32 == 0 
    assert inp_dim > 32

    if CUDA:
        model.cuda()
            
    model.eval()

    cap = cv2.VideoCapture(0)
    
    assert cap.isOpened(), 'Cannot capture source'
    
    frames = 0
    start = time.time()    
    while cap.isOpened():
        
        ret, frame = cap.read()
        if ret:
            
            img, orig_im, dim = prep_image(frame, inp_dim)
            
            im_dim = torch.FloatTensor(dim).repeat(1,2)                        
            
            
            if CUDA:
                im_dim = im_dim.cuda()
                img = img.cuda()
            
            
            output = model(Variable(img), CUDA)
            output = write_results(output, confidence, num_classes, nms = True, nms_conf = nms_thesh)

            if type(output) == int:
                frames += 1
                print("FPS of the video is {:5.2f}".format( frames / (time.time() - start)))
                cv2.imshow("frame", orig_im)
                key = cv2.waitKey(1)
                if key & 0xFF == ord('q'):
                    break
                continue
            

        
            output[:,1:5] = torch.clamp(output[:,1:5], 0.0, float(inp_dim))/inp_dim
            
#            im_dim = im_dim.repeat(output.size(0), 1)
            output[:,[1,3]] *= frame.shape[1]
            output[:,[2,4]] *= frame.shape[0]
            
            list(map(lambda x: write(x, orig_im), output))

            cv2.imshow("lane_tracking",lane_tracking(frame))            
            key = cv2.waitKey(1)&0xFF
            if key==27:
                break
            frames += 1
            print("FPS of the video is {:5.2f}".format( frames / (time.time() - start)))

            
        else:
            break
